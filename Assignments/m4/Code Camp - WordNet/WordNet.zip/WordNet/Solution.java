public class Solution {
	public static void main(String[] args) {
		String synsets = StdIn.readString();
		String hypernyms = StdIn.readString();
		WordNet wordnet = new WordNet(synsets, hypernyms);
		wordnet.readfile(synsets);

	}
}
