import java.util.Arrays;
public class WordNet {
        // private Digraph digraph;
        // private SAP sap;
        // private int grlength;
        // private LinearProbingHashST<String, Integer> st;


    public WordNet(String synsets, String hypernyms) {
        // digraph = new Digraph();
        // sap = new SAP();
        // grlength = 0;
        // st = new LinearProbingHashST<String, Integer>();
    }
    public void readfile(String file) {
        In in = new In(file);
        String[] s1 = null;
        while (in.hasNextLine()) {
        String[] s = in.readString().split(",");
        int id = Integer.parseInt(s[0]);
        s1 = s[1].split(" ");
        System.out.println(Arrays.toString(s1));
    }
}

    // returns all WordNet nouns
    // public Iterable<String> nouns()

    // // is the word a WordNet noun?
    // public boolean isNoun(String word)

    // // distance between nounA and nounB (defined below)
    // public int distance(String nounA, String nounB)

    // // a synset (second field of synsets.txt) that is the common ancestor of nounA and nounB
    // // in a shortest ancestral path (defined below)
    // public String sap(String nounA, String nounB)

    // // do unit testing of this class
    // public static void main(String[] args)
}
